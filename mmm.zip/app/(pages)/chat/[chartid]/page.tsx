

'use client';

import { usePathname } from 'next/navigation';
import { SearchImg } from '@/data/search/search';

const ChatDetailPage = () => {
  const pathname = usePathname();
  const chartid = parseInt(pathname.split('/')[2], 10);


  const chartData = SearchImg[chartid];

  if (!chartData) {
    return <div>Chart not found!</div>;
  }

  return (
    <div>
      <h1>Details for {chartData.name}</h1>
      <p>Age: {chartData.age}</p>
      {/* <p>Occupation: {chartData.occupation}</p> */}

      {/* Display multiple images */}
      <div>
        {chartData.mutipleImages.map((img, index) => (
          <img key={index} src={img.image} alt={`Image ${index + 1}`} width="200" />
        ))}
      </div>
    </div>
  );
};

export default ChatDetailPage;

