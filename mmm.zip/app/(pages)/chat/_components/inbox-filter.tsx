import React from 'react'

const InboxFilter = () => {
  return (
    <div className='w-[295px]'>InboxFilter</div>
  )
}

export default InboxFilter