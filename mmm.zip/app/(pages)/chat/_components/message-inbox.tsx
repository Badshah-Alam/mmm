import React from 'react'

const MessageInbox = () => {
  return (
    <div>message-inbox</div>
  )
}

export default MessageInbox