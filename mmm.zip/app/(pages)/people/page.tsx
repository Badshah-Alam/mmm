import React from 'react'

const page = () => {
  return (
    <div>people</div>
  )
}

export default page